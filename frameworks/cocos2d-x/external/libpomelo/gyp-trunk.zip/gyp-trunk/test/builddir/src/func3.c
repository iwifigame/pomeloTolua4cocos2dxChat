#include <stdio.h>

void func3(void)
{
  printf("Hello from func3.c\n");
}
