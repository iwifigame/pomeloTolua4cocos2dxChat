#include <stdio.h>

int main(int argc, char *argv[])
{
  printf("Hello from file1.c\n");
  return 0;
}
